/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sistemabiblioteca.interfaces;

import java.util.List;
import sistemabiblioteca.models.Users;

/**
 *
 * @author USER
 */
public interface DAOUsers {
    public void registrar(Users user) throws Exception;
    public void modificar(Users user) throws Exception;
    public void eliminar(int userId) throws Exception;
    public void sancionar(Users user) throws Exception;
    public List<Users> listar(String name) throws Exception;
    public Users getUserById(int userId) throws Exception;
}

