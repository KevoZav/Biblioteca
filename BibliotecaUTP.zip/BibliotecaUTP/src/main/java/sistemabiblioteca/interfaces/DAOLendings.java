/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sistemabiblioteca.interfaces;

import java.util.List;
import sistemabiblioteca.models.Lendings;
import sistemabiblioteca.models.Books;
import sistemabiblioteca.models.Users;

/**
 *
 * @author USER
 */
public interface DAOLendings {
    public void registrar(Lendings user) throws Exception;
    public void modificar(Lendings user) throws Exception;
    public Lendings getLending(Users user,Books book) throws Exception;
    //public void eliminar(Books user) throws Exception;
    public List<Lendings> listar() throws Exception;
}
