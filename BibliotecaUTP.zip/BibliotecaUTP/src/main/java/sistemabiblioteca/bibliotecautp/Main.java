/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemabiblioteca.bibliotecautp;

/**
 *
 * @author USER
 */
public class Main {
    
    public static void main(String[] args) {
        Dashboard login = new Dashboard();
        login.setVisible(true);
    }
}
